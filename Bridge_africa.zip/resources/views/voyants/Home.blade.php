@extends('layouts.app_agent')

@section('content_agent')

<div id="app">
    <container></container>
</div>
@endsection
