<?php $__env->startSection('content'); ?>


<div id="app">
    <messagej :users="<?php echo e(auth()->user()); ?>"></messagej>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\worckspace\Bridge_africa\resources\views/messageJ.blade.php ENDPATH**/ ?>