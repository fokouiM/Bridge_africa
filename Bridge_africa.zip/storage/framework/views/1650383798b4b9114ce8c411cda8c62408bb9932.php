<?php $__env->startSection('content_agent'); ?>

<div id="app">
    <container :users="<?php echo e(auth()->user()); ?>"></container>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app_agent', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\worckspace\Bridge_africa\resources\views/voyants/Home.blade.php ENDPATH**/ ?>