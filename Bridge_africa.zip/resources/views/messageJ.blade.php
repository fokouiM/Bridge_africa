@extends('layouts.app')

@section('content')

{{-- <div id="app">
    <message></message>
</div> --}}
<div id="app">
    <messagej ></messagej>
</div>

@endsection
