<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="assets/plugins/global/plugins.bundle.css" rel="stylesheet" type="text/css" />
    <link href="assets/plugins/custom/prismjs/prismjs.bundle.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/style.bundle.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/main.css" rel="stylesheet" type="text/css" />
    <title>voyance-auracle.fr</title>
    <style>
        .btnmail{
            color: #ffffff;
            background-color: #1BC5BD;
            border-color: #1BC5BD;
            width: auto;
            padding: 15px;
            position: absolute ;
            bottom: 5px;
            left: 1px;
            border-radius: 15px;
            float: right;
            text-align: center;
            margin-right: auto;
        }
        .bt{
            position: absolute ;
            bottom: 5px;
            right: ;: 1px;
        }
    </style>
</head>
<body style="min-width: 50vh;">
<p style="font-size: 16px" >{{$details['body']}}</p><br><br>
<div style="padding: auto; width: 100%;">
    <a href="http://voyance-auracle.fr/login" class="btnmail" style="
                color: #ffffff;
                background-color: #1BC5BD;
                border-color: #1BC5BD;
                padding: 15px;
                position: absolute ;
                bottom: 5px;
                left: 1px;
                border-radius: 5px;text-align: center;
                margin-left: auto;
                margin-right: auto;
    ">Cliquer ici</a>
</div><br><br>
<p >2021&copy; Voyance-auracle.fr tous droits réservés</p>
</body>
</html>
